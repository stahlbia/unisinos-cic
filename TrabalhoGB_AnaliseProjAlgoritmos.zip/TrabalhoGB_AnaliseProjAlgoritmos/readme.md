#  
Ana Beatriz Stahl e Gabriela Bley Rodrigues - Análise e Projeto de Algoritmos - Profa. Andriele Busatto do Carmo

A solução proposta utiliza um algoritmo de força bruta e uma solução utilizando programação dinâmica.

## Dependências
Esse projeto não possui dependências

## Como Rodar
Para rodar o algoritmo, execute o arquivo `programacao_dinamica.py` através do seguinte comando no terminal:

```
python programacao_dinamica.py
```